# STEDI Build Steps

`git clone https://github.com/BYUI-CIT-262/stedi-content`

`cd stedi-content`

`Docker build . -t stedi-content`

`Docker run stedi-content -p 8080:80`

Then open http://localhost:8080
